const mutations = {
  SET_USER(state, username) {
    state.username = username;
  },
  SET_NICKNAME(state, nickname) {
    state.nickname = nickname;
  }
}
export default mutations
