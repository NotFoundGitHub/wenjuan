const state = {
  // username: '',
  username: '',
  nickname: ''
}
export default state;
